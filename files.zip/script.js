function appendValue(value) {
  document.getElementById('result').value += value;
}

function clearResult() {
  document.getElementById('result').value = '';
}

function backspace() {
  const result = document.getElementById('result');
  result.value = result.value.slice(0, -1);
}

function calculate() {
  const result = document.getElementById('result');
  try {
    result.value = eval(result.value) || '';
  } catch {
    result.value = 'Error';
  }
}